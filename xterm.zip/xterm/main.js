const { app, BrowserWindow } = require('electron');

let win;

app.whenReady().then(() => {
    win = new BrowserWindow({
        width: 800,
        height: 600,
        webPreferences: {
            nodeIntegration: true, // ✅ Allow Node.js in renderer
            contextIsolation: false
        }
    });

    win.loadFile('index.html');
    win.webContents.openDevTools();
});
