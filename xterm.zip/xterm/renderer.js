const { Terminal } = require('xterm');
const { FitAddon } = require('xterm-addon-fit');
const { spawn } = require('child_process');

const term = new Terminal({
    cursorBlink: true,
    fontSize: 14,
    theme: {
        background: '#000000',
        foreground: '#ffffff'
    }
});

const fitAddon = new FitAddon();
term.loadAddon(fitAddon);
term.open(document.getElementById('terminal-container'));
fitAddon.fit();

let inputBuffer = ''; // Buffer to store input

// ✅ Start terminal process in the renderer
const shell = process.platform === 'win32' ? 'cmd.exe' : 'bash';
const terminalProcess = spawn(shell, [], { shell: true });

// ✅ Receive shell output and display it
terminalProcess.stdout.on('data', (data) => {
    term.write('\r\n' + data.toString());
});

terminalProcess.stderr.on('data', (data) => {
    term.write('\r\n' + data.toString());
});

terminalProcess.on('exit', () => {
    term.write('\r\n[Process exited]\r\n');
});

// ✅ Handle user input properly
term.onData((data) => {
    if (data === '\r') { // User pressed Enter
        terminalProcess.stdin.write(inputBuffer + '\n'); // Send full command
        inputBuffer = ''; // Clear input buffer
    } else if (data === '\x7f') { // Handle Backspace
        if (inputBuffer.length > 0) {
            inputBuffer = inputBuffer.slice(0, -1);
            term.write('\b \b'); // Remove last character from terminal
        }
    } else {
        inputBuffer += data;
        term.write(data); // Show input in terminal
    }
});

// ✅ Ensure terminal resizes properly
window.addEventListener('resize', () => fitAddon.fit());
