const { Terminal } = require('xterm');
const { FitAddon } = require('xterm-addon-fit');
const { spawn } = require('child_process');

class TerminalInstance {
    constructor(containerId) {
        this.term = new Terminal({
            cursorBlink: true,
            fontSize: 14,
            theme: {
                background: '#000000',
                foreground: '#ffffff'
            }
        });

        this.fitAddon = new FitAddon();
        this.term.loadAddon(this.fitAddon);

        // Create a new terminal container dynamically
        const terminalContainer = document.createElement('div');
        terminalContainer.classList.add('terminal-container');
        terminalContainer.id = containerId;
        document.getElementById('terminals').appendChild(terminalContainer);

        this.term.open(terminalContainer);
        this.fitAddon.fit();

        this.inputBuffer = ''; // Store user input

        // Spawn terminal process
        const shell = process.platform === 'win32' ? 'cmd.exe' : 'bash';
        this.terminalProcess = spawn(shell, [], { shell: true });

        // Handle terminal output
        this.terminalProcess.stdout.on('data', (data) => {
            this.term.write('\r\n' + data.toString());
        });

        this.terminalProcess.stderr.on('data', (data) => {
            this.term.write('\r\n' + data.toString());
        });

        this.terminalProcess.on('exit', () => {
            this.term.write('\r\n[Process exited]\r\n');
        });

        // Handle user input
        this.term.onData((data) => {
            if (data === '\r') { // Enter key
                this.terminalProcess.stdin.write(this.inputBuffer + '\n');
                this.inputBuffer = '';
            } else if (data === '\x7f') { // Backspace
                if (this.inputBuffer.length > 0) {
                    this.inputBuffer = this.inputBuffer.slice(0, -1);
                    this.term.write('\b \b');
                }
            } else {
                this.inputBuffer += data;
                this.term.write(data);
            }
        });

        // Adjust terminal size on window resize
        window.addEventListener('resize', () => this.fitAddon.fit());
    }
}

// Store multiple terminal instances
const terminals = [];

// Add new terminal on button click
document.getElementById('add-terminal').addEventListener('click', () => {
    const containerId = `terminal-${terminals.length}`;
    const newTerminal = new TerminalInstance(containerId);
    terminals.push(newTerminal);
});
